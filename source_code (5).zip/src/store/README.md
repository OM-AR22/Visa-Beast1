# Pages Directory

This is a store reserved directory. 