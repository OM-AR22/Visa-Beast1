import { useState, useEffect, useRef } from "react";
import { motion, useInView, useAnimation } from "framer-motion";
import visaBeastLogo from "./assets/visa-beast-logo.svg";

type PostType = "study" | "work";

type Post = {
  id: number;
  title: string;
  excerpt: string;
  country: string;
  type: PostType;
  tags: string[];
  author: string;
  date: string;
  image: string;
};

type News = {
  id: number;
  title: string;
  summary: string;
  category: string;
  source: string;
  date: string;
  isBreaking?: boolean;
};

const posts: Post[] = [
  {
    id: 1,
    title: "دليل المنح الدراسية في كندا لعام 2026",
    excerpt:
      "اكتشف أفضل برامج التمويل للطلاب العرب في الجامعات الكندية، مع نصائح للقبول وخطوات تجهيز الوثائق الرسمية.",
    country: "كندا",
    type: "study",
    tags: ["منح دراسية", "لغة إنجليزية", "تأشيرة طالب"],
    author: "ريما الحارثي",
    date: "2025-10-18",
    image: "/src/assets/canada-graduation.jpg",
  },
  {
    id: 2,
    title: "فرص العمل في قطاع التكنولوجيا بألمانيا",
    excerpt:
      "تعرف على المهارات المطلوبة، مستويات الرواتب، وكيفية معادلة الخبرات المهنية للحصول على عقد عمل في برلين وميونخ.",
    country: "ألمانيا",
    type: "work",
    tags: ["تقنية", "لغة ألمانية", "تصاريح العمل"],
    author: "سالم المدني",
    date: "2025-09-30",
    image: "/src/assets/germany-tech.jpg",
  },
  {
    id: 3,
    title: "برنامج الدراسة والعمل الجزئي في أستراليا",
    excerpt:
      "يجمع هذا البرنامج بين الدراسة الأكاديمية وفرص العمل بدوام جزئي، مع توضيح تكاليف المعيشة وخيارات السكن للطلاب.",
    country: "أستراليا",
    type: "study",
    tags: ["عمل جزئي", "تأمين صحي", "حياة طلابية"],
    author: "هالة بوزيد",
    date: "2025-11-04",
    image: "/src/assets/australia-student.jpg",
  },
  {
    id: 4,
    title: "كيف تحصل على تدريب مهني ممول في اليابان",
    excerpt:
      "خطوات التقديم على برامج التدريب المهني في طوكيو وأوساكا، وأهم مهارات اللغة والثقافة المطلوبة للنجاح.",
    country: "اليابان",
    type: "work",
    tags: ["تدريب", "لغة يابانية", "ثقافة عمل"],
    author: "جواد الشامي",
    date: "2025-08-21",
    image: "/src/assets/japan-business.jpg",
  },
];

const newsItems: News[] = [
  {
    id: 1,
    title: "بريطانيا تعلن عن فتح 50 ألف تأشيرة عمل جديدة للقطاع الصحي",
    summary: "وزارة الداخلية البريطانية تطلق برنامجًا جديدًا لجذب المهنيين الصحيين من جميع أنحاء العالم لسد النقص الحاد في القطاع",
    category: "تأشيرات",
    source: "وزارة الداخلية البريطانية",
    date: "2025-11-04",
    isBreaking: true,
  },
  {
    id: 2,
    title: "كندا ترفع الحد الأدنى لرواتب المهاجرين المهرة إلى 65 ألف دولار",
    summary: "التعديل الجديد على برنامج الهجرة السريعة يدخل حيز التنفيذ بداية العام المقبل",
    category: "هجرة",
    source: "وزارة الهجرة الكندية",
    date: "2025-11-03",
  },
  {
    id: 3,
    title: "ألمانيا تطلق منصة رقمية لتسهيل معادلة الشهادات الجامعية",
    summary: "نظام إلكتروني جديد يختصر الإجراءات من 6 أشهر إلى 4 أسابيع فقط",
    category: "تعليم",
    source: "وزارة التعليم الألمانية",
    date: "2025-11-02",
  },
  {
    id: 4,
    title: "أستراليا تزيد عدد ساعات العمل المسموحة للطلاب الدوليين",
    summary: "الطلاب الدوليون يمكنهم الآن العمل 30 ساعة أسبوعيًا بدلاً من 20 ساعة",
    category: "قوانين",
    source: "وزارة التعليم الأسترالية",
    date: "2025-11-01",
  },
  {
    id: 5,
    title: "دول الاتحاد الأوروبي تتفق على قواعد موحدة للتأشيرات الدراسية",
    summary: "اتفاقية جديدة تسمح للطلاب بالتنقل بحرية بين دول الاتحاد خلال فترة الدراسة",
    category: "سياسات",
    source: "المفوضية الأوروبية",
    date: "2025-10-30",
  },
];

const typeStyles: Record<PostType, { label: string; className: string }> = {
  study: { 
    label: "دراسة", 
    className: "bg-gradient-to-br from-emerald-50 to-emerald-100 text-emerald-800 border border-emerald-200/50" 
  },
  work: { 
    label: "عمل", 
    className: "bg-gradient-to-br from-amber-50 to-amber-100 text-amber-800 border border-amber-200/50" 
  },
};

const formatDate = (dateString: string) =>
  new Date(dateString).toLocaleDateString("ar-EG", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

// Animation component wrapper
const FadeInWhenVisible = ({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) => {
  const controls = useAnimation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  useEffect(() => {
    if (isInView) {
      controls.start("visible");
    }
  }, [isInView, controls]);

  return (
    <motion.div
      ref={ref}
      animate={controls}
      initial="hidden"
      transition={{ duration: 0.6, delay, ease: "easeOut" }}
      variants={{
        visible: { opacity: 1, y: 0 },
        hidden: { opacity: 0, y: 30 }
      }}
    >
      {children}
    </motion.div>
  );
};

function App() {
  const [hoveredPost, setHoveredPost] = useState<number | null>(null);
  const [hoveredNews, setHoveredNews] = useState<number | null>(null);

  return (
    <main
      dir="rtl"
      className="min-h-screen bg-[#faf8f5] text-neutral-900 overflow-hidden"
    >
      {/* Hero Section */}
      <div className="relative min-h-[70vh] sm:min-h-[85vh] flex items-center overflow-hidden">
        {/* Animated Background Patterns */}
        <div className="absolute inset-0">
          <motion.div 
            className="absolute top-0 left-0 w-[400px] sm:w-[600px] h-[400px] sm:h-[600px] rounded-full bg-emerald-100/30 blur-[100px]"
            animate={{
              x: [0, 50, 0],
              y: [0, 30, 0],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          <motion.div 
            className="absolute bottom-0 right-0 w-[500px] sm:w-[700px] h-[500px] sm:h-[700px] rounded-full bg-amber-100/20 blur-[120px]"
            animate={{
              x: [0, -50, 0],
              y: [0, -30, 0],
            }}
            transition={{
              duration: 25,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        </div>

        {/* Hero Content */}
        <section className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8 sm:mb-12"
          >
            <img 
              src={visaBeastLogo} 
              alt="Visa Beast - دليلك للدراسة والعمل في الخارج" 
              className="h-10 sm:h-12 md:h-14 w-auto"
            />
          </motion.div>

          <div className="max-w-5xl">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="inline-flex items-center gap-2 sm:gap-3 px-3 sm:px-5 py-2 sm:py-2.5 rounded-full bg-white/70 backdrop-blur-md border border-emerald-200/40 shadow-lg mb-6 sm:mb-10"
            >
              <motion.div 
                className="w-2.5 h-2.5 rounded-full bg-emerald-500"
                animate={{
                  scale: [1, 1.3, 1],
                  opacity: [1, 0.7, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
              <span className="text-xs sm:text-sm font-semibold text-emerald-800 tracking-wide">
                فرص حول العالم
              </span>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tight leading-[1.05] mb-6 sm:mb-10"
            >
              <span className="block bg-gradient-to-l from-neutral-900 via-neutral-800 to-neutral-900 bg-clip-text text-transparent">
                مدونة عربية
              </span>
              <span className="block bg-gradient-to-l from-emerald-600 via-emerald-700 to-amber-600 bg-clip-text text-transparent mt-2">
                للباحثين عن المستقبل
              </span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="text-base sm:text-xl md:text-2xl lg:text-3xl leading-relaxed text-neutral-600 max-w-3xl font-light mb-8 sm:mb-12"
            >
              نتابع أحدث الفرص التعليمية والمهنية الدولية، ونقدم أدلة عملية 
              لمساعدتك في التخطيط، التقديم، والانتقال إلى بلد جديد بثقة.
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="flex flex-col sm:flex-row flex-wrap gap-3 sm:gap-5"
            >
              <motion.button 
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.98 }}
                className="px-6 sm:px-10 py-3 sm:py-5 bg-gradient-to-br from-emerald-600 to-emerald-700 text-white text-base sm:text-lg rounded-xl sm:rounded-2xl font-bold shadow-2xl shadow-emerald-600/40 hover:shadow-emerald-600/60 active:scale-95 transition-all duration-300"
              >
                استكشف المقالات
              </motion.button>
              <motion.button 
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.98 }}
                className="px-6 sm:px-10 py-3 sm:py-5 bg-white/90 backdrop-blur-sm text-neutral-700 text-base sm:text-lg rounded-xl sm:rounded-2xl font-bold border-2 border-neutral-200/70 hover:bg-white hover:border-neutral-300 active:scale-95 transition-all duration-300 shadow-xl"
              >
                اشترك بالنشرة
              </motion.button>
            </motion.div>
          </div>
        </section>
      </div>

      {/* News Section */}
      <section className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24">
        <FadeInWhenVisible>
          <div className="flex items-center gap-3 sm:gap-4 mb-8 sm:mb-12">
            <div className="flex items-center gap-3">
              <div className="w-1.5 h-8 sm:h-10 bg-gradient-to-b from-red-500 to-red-600 rounded-full" />
              <h2 className="text-2xl sm:text-4xl md:text-5xl font-black text-neutral-900">
                آخر الأخبار
              </h2>
            </div>
            <motion.div 
              className="w-2.5 h-2.5 rounded-full bg-red-500"
              animate={{
                scale: [1, 1.4, 1],
                opacity: [1, 0.6, 1],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
              }}
            />
          </div>
        </FadeInWhenVisible>

        <div className="grid gap-4 sm:gap-6">
          {newsItems.map((news, index) => (
            <FadeInWhenVisible key={news.id} delay={index * 0.1}>
              <motion.article
                onHoverStart={() => setHoveredNews(news.id)}
                onHoverEnd={() => setHoveredNews(null)}
                whileHover={{ scale: 1.01, x: -5 }}
                whileTap={{ scale: 0.99 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className={`group relative rounded-2xl sm:rounded-3xl bg-white border overflow-hidden ${
                  news.isBreaking
                    ? 'border-red-200 shadow-[0_10px_40px_rgba(239,68,68,0.2)]'
                    : 'border-neutral-200/60 shadow-[0_6px_30px_rgb(0,0,0,0.06)]'
                }`}
              >
                {news.isBreaking && (
                  <motion.div 
                    initial={{ x: -100 }}
                    animate={{ x: 0 }}
                    className="absolute top-0 left-0 bg-gradient-to-r from-red-500 to-red-600 text-white text-xs font-black px-4 sm:px-5 py-1.5 sm:py-2 rounded-br-2xl shadow-lg z-10"
                  >
                    عاجل
                  </motion.div>
                )}

                <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 p-4 sm:p-7">
                  <div className="hidden sm:flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-xl sm:rounded-2xl bg-gradient-to-br from-neutral-100 to-neutral-200 text-neutral-700 font-black text-xl sm:text-2xl flex-shrink-0">
                    {String(index + 1).padStart(2, '0')}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                      <span className="px-3 sm:px-4 py-1 sm:py-1.5 rounded-lg sm:rounded-xl bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200/50">
                        {news.category}
                      </span>
                      <span className="text-xs sm:text-sm text-neutral-600 font-semibold">
                        {news.source}
                      </span>
                      <span className="hidden sm:inline text-sm text-neutral-400">•</span>
                      <time className="text-xs sm:text-sm text-neutral-500" dateTime={news.date}>
                        {formatDate(news.date)}
                      </time>
                    </div>

                    <h3 className="text-xl sm:text-2xl md:text-3xl font-black text-neutral-900 mb-2 sm:mb-3 leading-tight group-hover:text-emerald-700 transition-colors duration-300">
                      {news.title}
                    </h3>

                    <p className="text-base sm:text-lg text-neutral-600 leading-relaxed">
                      {news.summary}
                    </p>
                  </div>

                  <motion.div 
                    animate={{
                      x: hoveredNews === news.id ? -5 : 0,
                    }}
                    className="flex items-center justify-end sm:justify-center"
                  >
                    <div className="inline-flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-neutral-100 text-neutral-600 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300">
                      <svg 
                        className="w-5 h-5 sm:w-6 sm:h-6 transform rotate-180" 
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
                      </svg>
                    </div>
                  </motion.div>
                </div>
              </motion.article>
            </FadeInWhenVisible>
          ))}
        </div>

        <FadeInWhenVisible delay={0.5}>
          <div className="flex justify-center mt-8 sm:mt-14">
            <motion.button 
              whileHover={{ scale: 1.05, y: -3 }}
              whileTap={{ scale: 0.97 }}
              className="px-6 sm:px-10 py-3 sm:py-5 bg-gradient-to-br from-neutral-800 to-neutral-900 text-white rounded-xl sm:rounded-2xl font-black shadow-2xl hover:shadow-3xl active:scale-95 transition-all duration-300 flex items-center gap-2 sm:gap-3 text-base sm:text-lg"
            >
              <span>عرض جميع الأخبار</span>
              <motion.svg 
                animate={{ y: [0, 3, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="w-5 h-5 sm:w-6 sm:h-6" 
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 9l-7 7-7-7" />
              </motion.svg>
            </motion.button>
          </div>
        </FadeInWhenVisible>
      </section>

      {/* Posts Section */}
      <section className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24">
        <FadeInWhenVisible>
          <div className="flex items-center justify-between mb-8 sm:mb-14">
            <h2 className="text-2xl sm:text-4xl md:text-5xl font-black text-neutral-900">
              أحدث المقالات
            </h2>
            <div className="hidden sm:flex gap-3">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-4 sm:px-6 py-2 sm:py-3 bg-emerald-600 text-white rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm shadow-lg hover:shadow-xl hover:bg-emerald-700 transition-all"
              >
                الكل
              </motion.button>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-4 sm:px-6 py-2 sm:py-3 bg-white text-neutral-700 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm border-2 border-neutral-200 hover:bg-neutral-50 transition-all"
              >
                دراسة
              </motion.button>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-4 sm:px-6 py-2 sm:py-3 bg-white text-neutral-700 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm border-2 border-neutral-200 hover:bg-neutral-50 transition-all"
              >
                عمل
              </motion.button>
            </div>
          </div>
        </FadeInWhenVisible>

        <div className="grid gap-6 sm:gap-8 lg:gap-10 md:grid-cols-2">
          {posts.map((post, index) => (
            <FadeInWhenVisible key={post.id} delay={index * 0.15}>
              <motion.article
                onHoverStart={() => setHoveredPost(post.id)}
                onHoverEnd={() => setHoveredPost(null)}
                whileHover={{ scale: 1.02, y: -8 }}
                whileTap={{ scale: 0.99 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className="group relative rounded-2xl sm:rounded-[2rem] bg-white border border-neutral-200/60 shadow-[0_10px_40px_rgb(0,0,0,0.06)] overflow-hidden"
              >
                {/* Image Section */}
                <div className="h-48 sm:h-56 relative overflow-hidden">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-all duration-500" />
                  <div className="absolute top-4 sm:top-6 right-4 sm:right-6">
                    <span
                      className={`text-xs sm:text-sm font-black px-3 sm:px-5 py-1.5 sm:py-2 rounded-lg sm:rounded-xl shadow-lg backdrop-blur-sm ${typeStyles[post.type].className}`}
                    >
                      {typeStyles[post.type].label}
                    </span>
                  </div>
                </div>

                <div className="p-5 sm:p-8">
                  <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4 text-sm">
                    <span className="px-3 sm:px-4 py-1 sm:py-1.5 rounded-full bg-neutral-100 text-neutral-700 font-bold text-xs sm:text-sm border border-neutral-200/50">
                      {post.country}
                    </span>
                    <time className="text-xs sm:text-sm text-neutral-500 font-semibold" dateTime={post.date}>
                      {formatDate(post.date)}
                    </time>
                  </div>

                  <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-neutral-900 leading-tight mb-3 sm:mb-4 group-hover:text-emerald-700 transition-colors duration-300">
                    {post.title}
                  </h2>

                  <p className="text-base sm:text-lg text-neutral-600 leading-relaxed mb-4 sm:mb-6">
                    {post.excerpt}
                  </p>

                  <div className="flex flex-wrap gap-2 sm:gap-2.5 mb-6 sm:mb-8">
                    {post.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-3 sm:px-4 py-1 sm:py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-xs sm:text-sm font-bold border border-emerald-200/50"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-4 sm:pt-6 border-t-2 border-neutral-100">
                    <span className="text-sm sm:text-base text-neutral-600 font-bold">
                      بقلم {post.author}
                    </span>
                    <motion.a
                      href="#"
                      animate={{
                        x: hoveredPost === post.id ? -5 : 0,
                      }}
                      className="inline-flex items-center gap-2 sm:gap-2.5 text-emerald-700 hover:text-emerald-800 font-black text-sm sm:text-base transition-colors"
                    >
                      <span>اقرأ المزيد</span>
                      <svg 
                        className="w-4 h-4 sm:w-5 sm:h-5" 
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 19l-7-7 7-7" />
                      </svg>
                    </motion.a>
                  </div>
                </div>
              </motion.article>
            </FadeInWhenVisible>
          ))}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24">
        <FadeInWhenVisible>
          <motion.div 
            whileHover={{ scale: 1.01 }}
            className="relative rounded-2xl sm:rounded-[3rem] bg-gradient-to-br from-emerald-600 via-emerald-700 to-emerald-800 p-8 sm:p-12 lg:p-16 xl:p-20 overflow-hidden shadow-2xl"
          >
            {/* Animated Background Elements */}
            <motion.div 
              className="absolute top-0 right-0 w-64 sm:w-96 h-64 sm:h-96 rounded-full bg-white/10 blur-3xl"
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.3, 0.5, 0.3],
              }}
              transition={{
                duration: 8,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
            
            <div className="relative max-w-4xl mx-auto text-center">
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-white mb-6 sm:mb-8 leading-tight"
              >
                لا تفوت أي فرصة جديدة
              </motion.h2>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="text-base sm:text-xl md:text-2xl text-emerald-50 mb-8 sm:mb-12 leading-relaxed font-light"
              >
                اشترك في نشرتنا البريدية واحصل على آخر التحديثات حول فرص الدراسة والعمل في الخارج
              </motion.p>
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="flex flex-col sm:flex-row gap-3 sm:gap-5 max-w-2xl mx-auto"
              >
                <input
                  type="email"
                  placeholder="أدخل بريدك الإلكتروني"
                  className="flex-1 px-4 sm:px-7 py-3 sm:py-5 rounded-xl sm:rounded-2xl bg-white/95 backdrop-blur-sm text-neutral-900 placeholder:text-neutral-500 focus:outline-none focus:ring-4 focus:ring-white/50 transition-all text-base sm:text-lg font-medium shadow-xl"
                />
                <motion.button 
                  whileHover={{ scale: 1.05, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  className="px-6 sm:px-10 py-3 sm:py-5 bg-white text-emerald-700 rounded-xl sm:rounded-2xl font-black hover:bg-emerald-50 active:scale-95 transition-all duration-300 shadow-2xl text-base sm:text-lg whitespace-nowrap"
                >
                  اشترك الآن
                </motion.button>
              </motion.div>
            </div>
          </motion.div>
        </FadeInWhenVisible>
      </section>
    </main>
  );
}

export default App;
